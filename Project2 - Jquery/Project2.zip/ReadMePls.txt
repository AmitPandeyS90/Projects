Webpage Link-
https://people.rit.edu/~ap6932/ISTE340/Project2FWithMenu/#firstPage

Jquery plugin Used-

1. Fullpage
2. FancyBox
3. Datatables
4. Accordion
+1. Iframe for map


Extra Points claims-

1. Use of grep method to search for the array.
2. Student Resources Page - Used replace method on keys to insert space before capital letters and converted them into Camel Case